package com.jk.thunder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class ManualActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);
        WebView webManual = (WebView) findViewById(R.id.webManual);
        webManual.loadUrl("file:///android_asset/parking.html");
      //  webManual.loadUrl("http://www.google.com/search?q=Lambton");
    }
}
